#!/usr/bin/env bash
LIDAR_TYPE=$1
echo "export LIDAR_TYPE=$LIDAR_TYPE" >> ~/.bashrc
source ~/.bashrc
